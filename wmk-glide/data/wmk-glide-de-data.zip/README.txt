WMK glide typing - German measurement set
=========================================

What this is
------------
The exact data behind the numbers in the issue "Give glide typing a tuning profile
per language": 2,594 real German swipes, the layout they were drawn on, the word
list used, and the two patches that turn the repo's own benchmark into a
non-English one.

Files
-----
de_swipes.jsonl   2,594 German swipes, one JSON per line, format:
                  {"word": "<target>", "canvas_width": <px>, "canvas_height": <px>,
                   "data": [{"x": <0..1>, "y": <0..1>, "t": <ms>}, ...]}
                  x and y are normalised to the canvas, t is milliseconds from
                  touch-down. Filtered from FUTO's swipe-5: language "de",
                  layout "german", dual_finger == 0.
de_targets.txt    the 1,400 distinct target words, for the oracle runs.
de_150k.txt       FrequencyWords German, top 150,000 by frequency,
                  one "word count" per line.
german.json       FUTO's German layout: 11 columns, ü ö ä as keys, no ß.
                  Format: {"keys": [{"letter", "cx", "cy"}, ...]}, cx/cy in 0..1.
qwerty.json       FUTO's QWERTY layout, for the English cross-check.
harness.patch     git diff of native/wm-engine/examples/glide_beam_eval.rs:
                  COLS (column count from the layout), non-ASCII words, RESULTS
                  (result width), ALL (score every stroke), DUMP (per-stroke
                  output), SHAPES (learned-shape channel).
freq_weight.patch git diff of native/wm-engine/src/glide/mod.rs: freq_weight
                  (weight on ln(1+frequency)), length prior fields, both defaulting
                  to the shipped behaviour.

How to reproduce
----------------
    git clone https://github.com/wasi-master/wmkeyboard && cd wmkeyboard
    git apply harness.patch freq_weight.patch
    cd native/wm-engine
    cargo run --release --example glide_beam_eval -- \
        de_swipes.jsonl german.json de_150k.txt

    # one tuning per line on stdin, e.g. the German profile:
    echo "freq_weight=0.5 gap_weight=2.0" | COLS=11 ALL=1 THREADS=8 \
        ./target/release/examples/glide_beam_eval de_swipes.jsonl german.json de_150k.txt

Licences and attribution
------------------------
- Swipes (de_swipes.jsonl) and layouts (german.json, qwerty.json): from
  swipe.futo.org, © FUTO, MIT licence. Source:
  https://huggingface.co/datasets/futo-org/swipe.futo.org
- Word list (de_150k.txt): derived from FrequencyWords, MIT licence.
  Source: https://github.com/hermitdave/FrequencyWords (content/2018/de/de_full.txt)
- The two patches: yours, same licence as the repository they apply to.
